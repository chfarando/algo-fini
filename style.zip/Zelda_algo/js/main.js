function zelda() {

  var body = document.querySelector('body');
  var zqsd = [122, 100, 113, 115];

  var character = new Link(10, 10, body, zqsd);


}
zelda();
